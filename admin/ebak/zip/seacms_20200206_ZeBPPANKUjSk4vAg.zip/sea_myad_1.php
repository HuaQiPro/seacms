<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_myad`;");
E_C("CREATE TABLE `sea_myad` (
  `aid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adname` varchar(100) NOT NULL DEFAULT '',
  `adenname` varchar(60) NOT NULL DEFAULT '',
  `timeset` int(10) unsigned NOT NULL DEFAULT '0',
  `intro` char(255) NOT NULL DEFAULT '',
  `adsbody` text,
  PRIMARY KEY (`aid`),
  KEY `timeset` (`timeset`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `sea_myad` values('1',0x6368616e6e656c323030783230306274,0x6368616e6e656c323030783230306274,'1344397254',0xe6b58be8af95e5b9bfe5918a31,0x646f63756d656e742e77726974656c6e28223c64697620636c6173733d5c2272696768745f625f6e6569726f6e675c223e3c5c2f6469763e2229);");
E_D("replace into `sea_myad` values('2',0x6368616e6e656c32303078323030746f70,0x6368616e6e656c32303078323030746f70,'1344397271',0xe6b58be8af95e5b9bfe5918a32,0x646f63756d656e742e77726974656c6e28223c64697620636c6173733d5c2272696768745f745f6e6569726f6e675c223e3c5c2f6469763e2229);");
E_D("replace into `sea_myad` values('3',0x6368616e6e656c373238783930,0x6368616e6e656c373238783930,'1344397299',0xe6b58be8af95e5b9bfe5918a33,0x646f63756d656e742e77726974656c6e28223c64697620636c6173733d5c226775616e6767616f5f6e6569726f6e675c223e3c5c2f6469763e2229);");

require("../../inc/footer.php");
 ?>