<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_jqtype`;");
E_C("CREATE TABLE `sea_jqtype` (
  `tid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `upid` smallint(6) NOT NULL DEFAULT '0',
  `tname` char(30) NOT NULL DEFAULT '',
  `ishidden` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8");
E_D("replace into `sea_jqtype` values('1','0',0xe8a7a3e5af86,'0');");
E_D("replace into `sea_jqtype` values('2','0',0xe4b9a1e69d91,'0');");
E_D("replace into `sea_jqtype` values('3','0',0xe983bde5b882,'0');");
E_D("replace into `sea_jqtype` values('4','0',0xe5b091e584bf,'0');");
E_D("replace into `sea_jqtype` values('5','0',0xe5afb9e8af9d,'0');");
E_D("replace into `sea_jqtype` values('6','1',0xe6909ee7ac91,'0');");
E_D("replace into `sea_jqtype` values('7','1',0xe68190e68096,'0');");
E_D("replace into `sea_jqtype` values('8','1',0xe5aeabe5bbb7,'0');");
E_D("replace into `sea_jqtype` values('9','1',0xe589a7e68385,'0');");
E_D("replace into `sea_jqtype` values('10','2',0xe8a880e68385,'0');");
E_D("replace into `sea_jqtype` values('11','2',0xe5aeb6e5baad,'0');");
E_D("replace into `sea_jqtype` values('12','2',0xe58ab1e5bf97,'0');");
E_D("replace into `sea_jqtype` values('13','2',0xe581b6e5838f,'0');");
E_D("replace into `sea_jqtype` values('14','2',0xe697b6e8a385,'0');");
E_D("replace into `sea_jqtype` values('15','3',0xe5b9b4e4bba3,'0');");
E_D("replace into `sea_jqtype` values('16','3',0xe682ace79691,'0');");
E_D("replace into `sea_jqtype` values('17','3',0xe58fa4e8a385,'0');");
E_D("replace into `sea_jqtype` values('18','4',0xe783ade8a180,'0');");
E_D("replace into `sea_jqtype` values('19','4',0xe5908ce4baba,'0');");
E_D("replace into `sea_jqtype` values('20','4',0xe880bde7be8e,'0');");

require("../../inc/footer.php");
 ?>