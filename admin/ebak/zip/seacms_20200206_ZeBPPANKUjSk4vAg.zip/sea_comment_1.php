<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_comment`;");
E_C("CREATE TABLE `sea_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `v_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL DEFAULT '',
  `ip` char(15) NOT NULL DEFAULT '',
  `ischeck` smallint(6) NOT NULL DEFAULT '0',
  `dtime` int(10) unsigned NOT NULL DEFAULT '0',
  `msg` text,
  `m_type` int(6) unsigned NOT NULL DEFAULT '0',
  `reply` int(6) unsigned NOT NULL DEFAULT '0',
  `agree` int(6) unsigned NOT NULL DEFAULT '0',
  `anti` int(6) unsigned NOT NULL DEFAULT '0',
  `pic` char(255) NOT NULL DEFAULT '',
  `vote` int(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `v_id` (`v_id`,`ischeck`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `sea_comment` values('1','0','1','0','',0x3132372e302e302e31,'1','1580899775',0xe69c89e58d8ee59bbde9948be68cbae5a5bde5928ce6b395e59bbde88ab1e7b289e7aea1e88ab1e7b289e7aea1,'1','0','0','0','','0');");
E_D("replace into `sea_comment` values('2','1','1','0',0x7a7874383536,0x3132372e302e302e31,'1','1580909067',0xe585abe782b9e58f8de694bbe9ab98e6b5aee99b95e9acbce59cb0e696b9,'0','0','0','0','','0');");

require("../../inc/footer.php");
 ?>