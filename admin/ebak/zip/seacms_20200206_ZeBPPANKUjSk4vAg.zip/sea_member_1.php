<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_member`;");
E_C("CREATE TABLE `sea_member` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `nickname` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `email` char(255) NOT NULL DEFAULT '',
  `logincount` smallint(6) NOT NULL DEFAULT '0',
  `regip` varchar(16) NOT NULL DEFAULT '',
  `regtime` int(10) NOT NULL DEFAULT '0',
  `gid` smallint(4) NOT NULL,
  `points` int(10) NOT NULL DEFAULT '0',
  `state` smallint(4) NOT NULL DEFAULT '1',
  `stime` int(10) NOT NULL DEFAULT '1533686888',
  `vipendtime` varchar(15) NOT NULL,
  `acode` varchar(35) NOT NULL,
  `repswcode` varchar(35) NOT NULL,
  `msgbody` text,
  `msgstate` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `sea_member` values('1',0x7a7874383536,'',0x3161383337343034393036616566653333613732,0x73656165654071712e636f6d,'2',0x3132372e302e302e31,'1580909004','2','11','1','1580909018',0x31353830393039303034,0x6334383334376632396436623165633137646334303530333439363337376334,0x79,NULL,0x79);");

require("../../inc/footer.php");
 ?>