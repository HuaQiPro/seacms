<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_zyk`;");
E_C("CREATE TABLE `sea_zyk` (
  `zid` int(6) NOT NULL AUTO_INCREMENT,
  `zname` varchar(60) NOT NULL,
  `zapi` varchar(255) NOT NULL,
  `zinfo` varchar(255) NOT NULL DEFAULT '暂无',
  PRIMARY KEY (`zid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `sea_zyk` values('1',0x31313536e8b584e6ba90,0x687474703a2f2f636a2e313135367a792e636f6d2f696e632f736561636d736170692e706870,0xe69a82e697a0e68f8fe8bfb0);");

require("../../inc/footer.php");
 ?>