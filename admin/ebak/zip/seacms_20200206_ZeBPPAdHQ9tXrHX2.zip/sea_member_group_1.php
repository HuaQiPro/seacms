<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_member_group`;");
E_C("CREATE TABLE `sea_member_group` (
  `gid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gname` varchar(32) NOT NULL DEFAULT '',
  `gtype` varchar(255) NOT NULL DEFAULT '',
  `g_auth` varchar(32) NOT NULL DEFAULT '',
  `g_upgrade` int(11) NOT NULL DEFAULT '0',
  `g_authvalue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8");
E_D("replace into `sea_member_group` values('1',0xe6b8b8e5aea2e794a8e688b7,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'0','0');");
E_D("replace into `sea_member_group` values('2',0xe699aee9809ae4bc9ae59198,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'10','0');");
E_D("replace into `sea_member_group` values('3',0xe9939ce7898ce4bc9ae59198,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'100','0');");
E_D("replace into `sea_member_group` values('4',0xe993b6e7898ce4bc9ae59198,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'500','0');");
E_D("replace into `sea_member_group` values('5',0xe98791e7898ce4bc9ae59198,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'1000','0');");
E_D("replace into `sea_member_group` values('6',0xe992bbe79fb3e4bc9ae59198,0x312c322c332c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c3136,0x312c322c33,'3000','0');");

require("../../inc/footer.php");
 ?>