<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_type`;");
E_C("CREATE TABLE `sea_type` (
  `tid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `upid` tinyint(6) unsigned NOT NULL DEFAULT '0',
  `tname` char(30) NOT NULL DEFAULT '',
  `tenname` char(60) NOT NULL DEFAULT '',
  `torder` int(11) NOT NULL DEFAULT '0',
  `templist` char(50) NOT NULL DEFAULT '',
  `templist_1` char(50) NOT NULL DEFAULT '',
  `templist_2` char(50) NOT NULL DEFAULT '',
  `title` char(50) NOT NULL DEFAULT '',
  `keyword` char(50) NOT NULL DEFAULT '',
  `description` char(50) NOT NULL DEFAULT '',
  `ishidden` smallint(6) NOT NULL DEFAULT '0',
  `unionid` mediumtext,
  `tptype` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `upid` (`upid`,`ishidden`),
  KEY `torder` (`torder`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8");
E_D("replace into `sea_type` values('1','0',0xe794b5e5bdb1,0x6479,'1',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0',0x33315f31,'0');");
E_D("replace into `sea_type` values('2','0',0xe794b5e8a786e589a7,0x7476,'2',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('3','0',0xe7bbbce889ba,0x7a79,'3',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('4','0',0xe58aa8e6bcab,0x646d,'4',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('5','1',0xe58aa8e4bd9ce78987,0x646f6e677a756f,'5',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('6','1',0xe788b1e68385e78987,0x616971696e67,'6',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('7','1',0xe7a791e5b9bbe78987,0x6b656875616e,'7',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('8','1',0xe68190e68096e78987,0x6b6f6e676275,'8',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('9','1',0xe68898e4ba89e78987,0x7a68616e7a68656e67,'9',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('10','1',0xe5969ce589a7e78987,0x78696a75,'10',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('11','1',0xe7baaae5bd95e78987,0x6a696c75,'11',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('12','1',0xe589a7e68385e78987,0x6a7571696e67,'12',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('13','2',0xe5a4a7e99986e589a7,0x64616c75,'13',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0',0x315f3132,'0');");
E_D("replace into `sea_type` values('14','2',0xe6b8afe58fb0e589a7,0x74616e67746169,'14',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0',0x315f3133,'0');");
E_D("replace into `sea_type` values('15','2',0xe6aca7e7be8ee589a7,0x6f756d6569,'15',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('16','2',0xe697a5e99fa9e589a7,0x726968616e,'16',0x6368616e6e656c2e68746d6c,0x636f6e74656e742e68746d6c,0x706c61792e68746d6c,'','','','0','','0');");
E_D("replace into `sea_type` values('17','0',0xe59bbde58685,0x67756f6e6569,'17',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('18','0',0xe59bbde99985,0x67756f6a69,'18',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('19','0',0xe7a4bee4bc9a,0x736865687569,'19',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('20','0',0xe5869be4ba8b,0x6a756e736869,'20',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('21','0',0xe5a8b1e4b990,0x79756c65,'21',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('22','0',0xe585abe58da6,0x6261677561,'22',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('23','0',0xe7a791e68a80,0x6b656a69,'23',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('24','0',0xe8b4a2e7bb8f,0x6361696a696e67,'24',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('25','0',0xe585ace79b8a,0x676f6e677969,'25',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('26','0',0xe8af84e8aeba,0x70696e676c756e,'26',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");
E_D("replace into `sea_type` values('27','0',0xe697b6e5b09a,0x7368697368616e67,'27',0x6e657773706167652e68746d6c,0x6e6577732e68746d6c,0x706c61792e68746d6c,'','','','0','','1');");

require("../../inc/footer.php");
 ?>