<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_co_cls`;");
E_C("CREATE TABLE `sea_co_cls` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `clsname` varchar(50) NOT NULL DEFAULT '',
  `sysclsid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cotype` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sysclsid` (`sysclsid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8");
E_D("replace into `sea_co_cls` values('1',0xe5a4a7e99986,'0','0');");
E_D("replace into `sea_co_cls` values('2',0xe9a699e6b8af,'0','0');");
E_D("replace into `sea_co_cls` values('3',0xe58fb0e6b9be,'0','0');");
E_D("replace into `sea_co_cls` values('4',0xe697a5e69cac,'0','0');");
E_D("replace into `sea_co_cls` values('5',0xe99fa9e59bbd,'0','0');");
E_D("replace into `sea_co_cls` values('6',0xe6aca7e7be8e,'0','0');");
E_D("replace into `sea_co_cls` values('7',0xe697a5e99fa9,'0','0');");
E_D("replace into `sea_co_cls` values('8',0xe4b8ade59bbd,'0','0');");

require("../../inc/footer.php");
 ?>