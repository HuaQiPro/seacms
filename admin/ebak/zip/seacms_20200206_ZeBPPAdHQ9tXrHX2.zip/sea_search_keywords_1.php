<?php
define('InEmpireBakData',TRUE);
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 5.1
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `sea_search_keywords`;");
E_C("CREATE TABLE `sea_search_keywords` (
  `aid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` char(30) NOT NULL DEFAULT '',
  `spwords` char(50) NOT NULL DEFAULT '',
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  `result` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `sea_search_keywords` values('1',0xe88c83e5beb7e890a8,0xe88c83e5beb7,'2','0','1580900957','0');");
E_D("replace into `sea_search_keywords` values('2',0x31,0x31,'5','0','1580901041','0');");
E_D("replace into `sea_search_keywords` values('3',0xe4b8aa,0xe4b8aa,'4','0','1580901149','0');");

require("../../inc/footer.php");
 ?>